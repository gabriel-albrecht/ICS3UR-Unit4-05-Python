#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2019
# This program adds positive numbers


def main():
    # this function uses a continue statement

    try:
        # input
        time = int(input("How many numbers will you add?: "))
        print("")

        # process & output
        i = 0
        su = 0
        while i < time:
            num = float(input("Enter a positive number: "))
            if num < 0:
                i += 1
                continue
            else:
                su += num
                i += 1
        print("")
        print("The sum of the positive numbers is {}".format(su))

    except ValueError:
        print("")
        print("That is not a valid number.")


if __name__ == "__main__":
    main()
